import item1image1 from "../images/item1/1.webp";
import item1image2 from "../images/item1/2.webp";
import item1image3 from "../images/item1/3.webp";
import item1image4 from "../images/item1/4.webp";
import item2image1 from "../images/item2/1.webp";
import item2image2 from "../images/item2/2.webp";
import item2image3 from "../images/item2/3.webp";
import item2image4 from "../images/item2/4.webp";
import item3image1 from "../images/item3/1.webp";
import item3image2 from "../images/item3/2.webp";
import item3image3 from "../images/item3/3.webp";
import item3image4 from "../images/item3/4.webp";
import item4image1 from "../images/item4/1.webp";
import item4image2 from "../images/item4/2.webp";
import item4image3 from "../images/item4/3.webp";
import item4image4 from "../images/item4/4.webp";

const products = [
    {
        id: 0,
        name: 'Nokia Android Smartphone',
        price: '$480',
        description: "n publishing and graphic design, Lorem ipsum is a placeholder text commonly used to " +
            "demonstrate the visual form of a document or a typeface without relying on meaningful " +
            "content. Lorem ipsum may be used as a placeholder before the final copy is available.",
        clicks: 0,
        images : [
            {
                original: item1image1,
                thumbnail: item1image1,
            },
            {
                original: item1image2,
                thumbnail: item1image2,
            },
            {
                original: item1image3,
                thumbnail: item1image3,
            },
            {
                original: item1image4,
                thumbnail: item1image4,
            }
        ],
    },
    {
        id: 1,
        name: 'Black and White Airpods',
        price: '$30',
        description: "n publishing and graphic design, Lorem ipsum is a placeholder text commonly used to " +
            "demonstrate the visual form of a document or a typeface without relying on meaningful " +
            "content. Lorem ipsum may be used as a placeholder before the final copy is available.",
        images : [
            {
                original: item2image1,
                thumbnail: item2image1,
            },
            {
                original: item2image2,
                thumbnail: item2image2,
            },
            {
                original: item2image3,
                thumbnail: item2image3,
            },
            {
                original: item2image4,
                thumbnail: item2image4,
            }
        ],
    },
    {
        id: 2,
        name: 'Sport Smartwatch 41mm',
        price: '$259',
        description: "n publishing and graphic design, Lorem ipsum is a placeholder text commonly used to " +
            "demonstrate the visual form of a document or a typeface without relying on meaningful " +
            "content. Lorem ipsum may be used as a placeholder before the final copy is available.",
        images : [
            {
                original: item3image1,
                thumbnail: item3image1,
            },
            {
                original: item3image2,
                thumbnail: item3image2,
            },
            {
                original: item3image3,
                thumbnail: item3image3,
            },
            {
                original: item3image4,
                thumbnail: item3image4,
            }
        ],
    },
    {
        id: 3,
        name: '18W Xiaomi Charger',
        price: '$19',
        description: "n publishing and graphic design, Lorem ipsum is a placeholder text commonly used to " +
            "demonstrate the visual form of a document or a typeface without relying on meaningful " +
            "content. Lorem ipsum may be used as a placeholder before the final copy is available.",
        images : [
            {
                original: item4image1,
                thumbnail: item4image1,
            },
            {
                original: item4image2,
                thumbnail: item4image2,
            },
            {
                original: item4image3,
                thumbnail: item4image3,
            },
            {
                original: item4image4,
                thumbnail: item4image4,
            }
        ],
    }
]
export default products
