import React from 'react';
import Header from '../Header/Header';

function Shop() {
    const products = [
        { id: 1, name: 'Product 1', description: 'Description 1', price: 10.99, image: 'https://picsum.photos/200/300?random=1' },
        { id: 2, name: 'Product 2', description: 'Description 2', price: 15.99, image: 'https://picsum.photos/200/300?random=2' },
        { id: 3, name: 'Product 3', description: 'Description 3', price: 20.99, image: 'https://picsum.photos/200/300?random=3' },
        { id: 4, name: 'Product 4', description: 'Description 4', price: 25.99, image: 'https://picsum.photos/200/300?random=4' },
        { id: 5, name: 'Product 5', description: 'Description 5', price: 30.99, image: 'https://picsum.photos/200/300?random=5' },
        { id: 6, name: 'Product 6', description: 'Description 6', price: 35.99, image: 'https://picsum.photos/200/300?random=6' }    // Add more products here
      ];
    

  return (
    <>
         <Header />
      <div className="bg-gray-100 min-h-screen p-4">
       

        <div className="container mx-auto px-4">
          <div className="flex flex-wrap -mx-4">
            {products.map(product => (
              <div key={product.id} className="w-full md:w-1/3 px-4 mb-4">
                <div className="bg-white shadow-md rounded-lg overflow-hidden">
                  <img src={product.image} alt="Product image" className="w-full h-48 object-cover object-center" />
                  <div className="p-4">
                    <h2 className="text-lg font-bold text-gray-800">{product.name}</h2>
                    <p className="text-gray-600">{product.description}</p>
                    <div className="flex items-center justify-between mt-4">
                      <span className="text-lg font-bold text-gray-800">${product.price}</span>
                      <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">Add to Cart</button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}

export default Shop;