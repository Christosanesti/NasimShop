function SignupInput (props) {
    return (
        <div>
            <fieldset className={props.classNames}>
                <input type={props.type} placeholder={props.placeholder}/>
            </fieldset>
        </div>
    )
}

export default SignupInput
