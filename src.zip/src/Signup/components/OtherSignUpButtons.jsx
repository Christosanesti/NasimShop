function OtherSignUpButtons (props) {
    return (
        <a href="#" className={props.classNames}>
            {props.text}
        </a>
    )
}

export default OtherSignUpButtons
