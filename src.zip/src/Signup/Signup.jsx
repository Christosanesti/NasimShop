import Header from "../Header/Header.jsx";
import "./Signup.css"
import OtherSignUpButtons from "./components/OtherSignUpButtons.jsx";
import SignupInput from "./components/SignupInput.jsx";
function Signup () {
    return (
        
        <div>
            <Header />
            <div className="signup">
                <div className="signup-connect">
                    <h1>Create your account</h1>
                    <OtherSignUpButtons text={"Sign in with Facebook"} classNames={"btn btn-social btn-facebook"} />
                    <OtherSignUpButtons text={"Sign in with Twitter"} classNames={"btn btn-social btn-twitter"} />
                    <OtherSignUpButtons text={"Sign in with Google"} classNames={"btn btn-social btn-google"} />
                    <OtherSignUpButtons text={"Sign in with Linkedin"} classNames={"btn btn-social btn-linkedin"} />
                </div>
                <div className="signup-classic">
                    <h2>Or use the classical way</h2>
                    <form className="form">
                        <SignupInput classNames={"username"} type={"text"} placeholder={"username"} />
                        <SignupInput classNames={"email"} type={"email"} placeholder={"email"} />
                        <SignupInput classNames={"password"} type={"password"} placeholder={"password"} />
                        <button type="submit" className="btn">sign up</button>
                    </form>
                </div>
            </div>
        </div>
    )
}

export default Signup
