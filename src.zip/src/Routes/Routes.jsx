import {Route, Routes} from "react-router-dom";
import Signin from "../Signin/Signin.jsx";
import Shop from "../Shop/Shop.jsx";
import Home from "../Home/Home.jsx";
import Dashboard from "../Dashboard/Dashboard.jsx";
import AdminDashboard from "../Admin-Dashboard/AdminDashboard.jsx";
import Signup from "../Signup/Signup.jsx";
const AppRoutes = () => {
    return (
        <Routes>
            <Route path={"/"} element={<Home />} />
            <Route path={"/shop"} element={<Shop />} />
            <Route path={"/signin"} element={<Signin />} />
            <Route path={"/dashboard"} element={<Dashboard />} />
            <Route path={"/admin-dashboard"} element={<AdminDashboard />} />
            <Route path={"/signup"} element={<Signup />} />
        </Routes>
    )
}
export default AppRoutes
