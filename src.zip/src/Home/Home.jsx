import Header from "../Header/Header.jsx";
import ImageGallery from "react-image-gallery";
import "react-image-gallery/styles/css/image-gallery.css";

const images = [
  {
    original: "https://picsum.photos/id/1019/1920/1080/",
    thumbnail: "https://picsum.photos/id/1019/250/150/",
  },
  {
    original: "https://picsum.photos/id/1012/1920/1080/",
    thumbnail: "https://picsum.photos/id/1012/250/150/",
  },
  {
    original: "https://picsum.photos/id/1013/1920/1080/",
    thumbnail: "https://picsum.photos/id/1013/250/150/",
  },
];

const Home = () => {
  return (
    <div className="min-h-screen bg-gray-100">
      <Header />
      <main className="container mx-auto py-8 px-4">
        <section className="mb-8">
          <h1 className="text-4xl font-bold text-center text-blue-600 mb-4">Welcome to Nasim's Shop</h1>
          <p className="text-center text-gray-700 mb-8">
            Explore our collection of beautiful items.
          </p>
        </section>
        <section className="shadow-lg rounded-lg overflow-hidden bg-white p-4">
          <ImageGallery items={images} showThumbnails={true} />
        </section>
      </main>
    </div>
  );
};

export default Home;