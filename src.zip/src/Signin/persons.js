const persons = [
    {
        id: 1,
        name: "shila",
        password: "2112",
        admin: false
    },
    {
        id: 2,
        name: "shila2",
        password: "3113",
        admin: true
    }
]
export default persons
