import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import SigninInput from "./components/SigninInput.jsx";
import SigninButton from "./components/SigninButton.jsx";
import Header from "../Header/Header.jsx";
import "./Signin.css";
import persons from "./persons.js";
function Signin() {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [errorMessage, setErrorMessage] = useState('');
    const navigate = useNavigate();

    const handleSubmit = (event) => {

        event.preventDefault();

        const foundUser = persons.find(
            (person) => person.name === username && person.password === password
        );

        if (foundUser) {
            const currentTime = new Date();
            setErrorMessage('');
            navigate(foundUser.admin ? '/admin-dashboard' : '/dashboard', { state: { lastLogin: currentTime } });
        } else {
            setErrorMessage('Invalid username or password');
        }
    };

    return (
        <>
            <Header />
            <div className="signin-container">
                <div className="background">
                    <div className="shape"></div>
                    <div className="shape"></div>
                </div>
                <form className="signin-form" onSubmit={handleSubmit}>
                    <h3>Login Here</h3>
                    <SigninInput
                        label={"Username"}
                        type={"text"}
                        placeholder={"Email or Phone"}
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                    />
                    <SigninInput
                        label={"Password"}
                        type={"password"}
                        placeholder={"Password"}
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                    />
                    {errorMessage && <p className="error-message">{errorMessage}</p>}
                    <SigninButton text={"Login"} type="submit" />
                    <div className="social">
                        <SigninButton text={"Google"} disabled={true} />
                        <SigninButton text={"Facebook"} disabled={true} />
                    </div>
                </form>
            </div>
        </>
    );
}

export default Signin;
