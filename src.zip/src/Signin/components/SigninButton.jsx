function SigninButton (props) {
    return (
        <div>
            <button className="signin-button">{props.text}</button>
        </div>
    )
}

export default SigninButton
