function SigninInput (props) {
    return (
        <div>
            <label className="signin-label">
                {props.label}
            </label>
            <input type={props.type} placeholder={props.placeholder} className="signin-input" onChange={props.onChange}/>
        </div>
)
}

export default SigninInput
