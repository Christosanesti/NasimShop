
import { useLocation } from 'react-router-dom';
import {useEffect, useState} from "react";
import Axios from "axios";

function Dashboard() {
    const [firstUser, setFirstUser] = useState("")
    const [secondUser, setSecondUser] = useState("")
    useEffect(() => {
        Axios.post("http://localhost:3001/total-users").then((response) => {
            console.log(response.data)
            setFirstUser(response.data[0].name)
            setSecondUser(response.data[1].name)
        });
    }, []);
    const location = useLocation();
    const lastLogin = location.state?.lastLogin;

    return (
        <div>
            <h1>Welcome back!</h1>
            <p>Last login: {lastLogin.toLocaleString()}</p>
            <p>Total users: {firstUser}</p>
            <p>Total users: {secondUser}</p>
        </div>
    );
}
export default Dashboard
