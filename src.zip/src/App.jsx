import './App.css'
import AppRoutes from "./Routes/Routes.jsx";

function App() {
  return (
      <div>
          <AppRoutes />
      </div>
  )
}

export default App
