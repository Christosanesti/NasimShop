import { Link, useNavigate } from "react-router-dom";
import Logo from "../../src/images/logo.png";

const navigation = [
  { name: 'Shop', url: '/shop' },
  { name: 'Home', url: '/' },
];

const Header = () => {
  const navigate = useNavigate();
  return (
    <header className="bg-blue-600 text-white shadow-md">
      <nav className="flex items-center justify-between p-6 lg:px-8" aria-label="Global">
        <div className="flex lg:flex-1">
          <Link to="/" className="-m-1.5 p-1.5">
            <img className="h-8 w-auto" src={Logo} alt="Logo" />
          </Link>
        </div>
        <div className="hidden md:flex gap-x-12">
          {navigation.map((item) => (
            <Link
              key={item.name}
              to={item.url}
              className="text-sm font-semibold leading-6 hover:text-gray-300"
            >
              {item.name}
            </Link>
          ))}
        </div>
        <div className="lg:flex lg:flex-1 lg:justify-end gap-x-4">
          <Link
            to="/signin"
            className="text-sm font-semibold leading-6 hover:text-gray-300 cursor-pointer"
          >
            Sign In <span aria-hidden="true">&rarr;</span>
          </Link>
          <Link
            to="/signup"
            className="text-sm font-semibold leading-6 hover:text-gray-300 cursor-pointer"
          >
            Sign Up <span aria-hidden="true">&rarr;</span>
          </Link>
        </div>
        <div className="md:hidden">
          <button
            type="button"
            className="text-white hover:text-gray-300 focus:outline-none focus:text-gray-300"
            aria-label="Toggle menu"
          >
            <svg className="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16m-7 6h7"></path>
            </svg>
          </button>
        </div>
      </nav>
      <hr className="border-gray-200" />
    </header>
  );
};

export default Header;